package br.puc.robobattle.combat;

public enum Action {
    ATTACK, DEFEND, SPECIAL
}
